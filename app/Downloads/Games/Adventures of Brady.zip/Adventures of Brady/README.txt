*****RUNNING THE PROGRAM********

These programs work on Windows machines as far as I know.
Click the program to run it. It is possible that Windows may something along the lines of "Windows protected your PC"
In order to run the program  click on More info and then an option will appear on the bottom right "Run anyway"
Click "Run anyway" and you should be able to play the game
