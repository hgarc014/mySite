This is a basic terminal based game. This also only works in windows and it will bring up a windows command shell.
